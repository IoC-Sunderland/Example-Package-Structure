from .example import my_func
