def my_func():
  return 'Hi, we made it'
 
